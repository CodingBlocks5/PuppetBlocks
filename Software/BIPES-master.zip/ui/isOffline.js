<script>
  function isOffline() {
      return true;
  }
</script>